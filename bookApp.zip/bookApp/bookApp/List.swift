//
//  List.swift
//  bookApp
//
//  Created by René Zelada on 8/31/21.
//

import Foundation

struct List: Codable {
    let Title : String
    let Author : String
    let Image : String
}
